# Perspective_Pivot
Web view framework for binary files to show into Pivot like structure
